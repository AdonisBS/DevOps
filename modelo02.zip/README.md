# DevOps
 Biblioteca de funções e aplicativos JavaScript.
